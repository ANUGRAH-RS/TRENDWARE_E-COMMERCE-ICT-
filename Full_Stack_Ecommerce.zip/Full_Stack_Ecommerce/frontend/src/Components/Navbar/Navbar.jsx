import React, { useContext, useRef, useState } from 'react';
import './Navbar.css';
import { Link } from 'react-router-dom';
import logo from '../Assets/logo.png';
import cart_icon from '../Assets/cart_icon.png';
import { ShopContext } from '../../Context/ShopContext';
import nav_dropdown from '../Assets/nav_dropdown.png';

import styled from 'styled-components';

const NavbarContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 20px;
  background-color: #f8f8f8;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
`;

const LogoLink = styled(Link)`
  display: flex;
  align-items: center;
  text-decoration: none;
  color: #333;

  img {
    width: 50px;
    height: auto;
  }

  p {
    margin-left: 10px;
    font-size: 1.5rem;
    font-weight: bold;
  }
`;

const DropdownIcon = styled.img`
  display: none;
  cursor: pointer;

  @media (max-width: 768px) {
    display: block;
  }
`;

const Menu = styled.ul`
  display: flex;
  list-style: none;
  margin: 0;
  padding: 0;

  @media (max-width: 768px) {
    display: none;
    position: absolute;
    top: 60px;
    left: 0;
    width: 100%;
    background-color: #f8f8f8;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    flex-direction: column;
    &.nav-menu-visible {
      display: flex;
    }
  }
`;

const MenuItem = styled.li`
  margin: 0 15px;
  cursor: pointer;
  position: relative;

  a {
    text-decoration: none;
    color: #333;
    font-size: 1rem;
    transition: color 0.3s;

    &:hover {
      color: #000;
    }
  }

  hr {
    border: none;
    border-bottom: 2px solid #333;
    width: 100%;
    position: absolute;
    bottom: -5px;
    left: 0;
  }
`;

const SearchContainer = styled.div`
  display: flex;
  align-items: center;
`;

const SearchInput = styled.input`
  padding: 8px 12px;
  border: 1px solid #ccc;
  border-radius: 20px;
  outline: none;
  font-size: 1rem;
  width: 200px;

  &:focus {
    border-color: #555;
  }
`;

const SearchButton = styled.button`
  background-color: #333;
  color: #fff;
  border: none;
  border-radius: 20px;
  padding: 8px 16px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #555;
  }
`;

const Navbar = () => {
  let [menu, setMenu] = useState('shop');
  const { getTotalCartItems } = useContext(ShopContext);

  const menuRef = useRef();

  const dropdown_toggle = (e) => {
    menuRef.current.classList.toggle('nav-menu-visible');
    e.target.classList.toggle('open');
  };

  const handleSearch = () => {
    // Implement your search functionality here
    console.log('Search functionality will be implemented here');
  };

  return (
    <NavbarContainer>
      <LogoLink to='/' onClick={() => { setMenu('shop'); }}>
        <img src={logo} alt="logo" />
        <p>TRENDWARE</p>
      </LogoLink>
      <Menu ref={menuRef} className="nav-menu">
        <MenuItem onClick={() => { setMenu('shop'); }}>
          <Link to='/'>SHOP</Link>
          {menu === 'shop' && <hr />}
        </MenuItem>
        <MenuItem onClick={() => { setMenu('mens'); }}>
          <Link to='/mens'>MEN</Link>
          {menu === 'mens' && <hr />}
        </MenuItem>
        <MenuItem onClick={() => { setMenu('womens'); }}>
          <Link to='/womens'>WOMEN</Link>
          {menu === 'womens' && <hr />}
        </MenuItem>
        <MenuItem onClick={() => { setMenu('kids'); }}>
          <Link to='/kids'>KIDS</Link>
          {menu === 'kids' && <hr />}
        </MenuItem>
      </Menu>
      <SearchContainer>
        <SearchInput type="text" placeholder="Search..." />
        <SearchButton onClick={handleSearch}>Search</SearchButton>
      </SearchContainer>
      <div className="nav-login-cart">
        {localStorage.getItem('auth-token')
          ? <button onClick={() => { localStorage.removeItem('auth-token'); window.location.replace('/'); }}>Logout</button>
          : <Link to='/login' style={{ textDecoration: 'none' }}><button>Login</button></Link>}
        <Link to="/cart"><img src={cart_icon} alt="cart" /></Link>
        <div className="nav-cart-count">{getTotalCartItems()}</div>
      </div>
      <DropdownIcon onClick={dropdown_toggle} src={nav_dropdown} alt="dropdown icon" />
    </NavbarContainer>
  );
};

export default Navbar;
