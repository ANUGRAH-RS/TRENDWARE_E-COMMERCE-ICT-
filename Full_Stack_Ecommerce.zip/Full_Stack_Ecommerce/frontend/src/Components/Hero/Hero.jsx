import React from 'react';
import styled from 'styled-components';
import Slider from 'react-slick';
import 'slick-carousel/slick/slick.css';
import 'slick-carousel/slick/slick-theme.css';
import hero_image from '../Assets/hero_image.png';
import hero_image1 from '../Assets/hero_image1.png';
import hero_image2 from '../Assets/hero_image2.png';
import hand_icon from '../Assets/hand_icon.png';
import arrow_icon from '../Assets/arrow.png';

const HeroContainer = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 40px 20px;
  background-color: #f2f2f2;
  color: #333;
  position: relative;
  overflow: hidden;
`;

const HeroLeft = styled.div`
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  z-index: 1;
  padding: 20px;

  h2 {
    font-size: 2rem;
    font-weight: strong;
    margin-bottom: 20px;
    color: #ff63666;
  }

  > div {
    display: flex;
    align-items: center;
    margin-bottom: 20px;

    p {
      font-size: 1.5rem;
      margin: 0 10px;
    }
  }
`;

const HeroHandIcon = styled.div`
  display: flex;
  align-items: center;
  background-color: #ff6347;
  color: #fff;
  padding: 5px 10px;
  border-radius: 5px;
  margin-right: 10px;

  p {
    margin: 0;
    font-size: 1rem;
    margin-right: 5px;
  }

  img {
    width: 20px;
    height: auto;
  }
`;

const HeroLatestBtn = styled.div`
  display: flex;
  align-items: center;
  background-color: #333;
  color: #fff;
  padding: 10px 20px;
  border-radius: 5px;
  cursor: pointer;
  transition: background-color 0.3s;

  &:hover {
    background-color: #555;
  }

  img {
    width: 20px;
    height: auto;
    margin-left: 10px;
  }
`;

const HeroRight = styled.div`
  flex: 1;
  display: flex;
  justify-content: center;
  align-items: center;

  img {
    width: 100%;
    height: auto;
  }
`;

const SliderContainer = styled.div`
  width: 100%;
  max-width: 600px;
  margin: 0 auto;

  .slick-prev, .slick-next {
    z-index: 2;
  }

  .slick-dots li button:before {
    color: #ff6347;
  }

  .slick-dots li.slick-active button:before {
    color: #ff6347;
  }
`;

const Hero = () => {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000, // Change slides every 3 seconds
  };

  return (
    <HeroContainer>
      <HeroLeft>
        <h2><b>TRENDWARE</b></h2>
        <div>
         <p>Stay ahead of the fashion curve with our new arrivals. Featuring the latest designs, 
          colors etc.. is perfect for every occasion.
          </p>
          
        </div>
        <HeroLatestBtn>
          <div>Latest Collection Store</div>
          <img src={arrow_icon} alt="arrow icon" />
        </HeroLatestBtn>
      </HeroLeft>
      <HeroRight>
        <SliderContainer>
          <Slider {...settings}>
            <div>
              <img src={hero_image1} alt="hero" />
            </div>
            <div>
              <img src={hero_image2} alt="hero" />
            </div>
            <div>
              <img src={hero_image} alt="hero" />
            </div>
          </Slider>
        </SliderContainer>
      </HeroRight>
    </HeroContainer>
  );
};

export default Hero;
