import React from 'react';
import styled from 'styled-components';

// Styled components for the About section
const AboutContainer = styled.div`
  background-color: #fff;
  padding: 50px;
  text-align: center;
`;

const MissionStatement = styled.p`
  font-size: 1.2rem;
  color: #333;
`;

const Vision = styled.p`
  font-size: 1.1rem;
  color: #555;
  margin-top: 20px;
`;

const Values = styled.ul`
  list-style: none;
  margin-top: 30px;
  padding: 0;
`;

const ValueItem = styled.li`
  font-size: 1rem;
  color: #777;
  margin-bottom: 10px;
`;

const About = () => {
  return (
    <AboutContainer>
      <h2>About Trendware</h2>
      <MissionStatement>
        At Trendware, our mission is to redefine fashion by offering trendy and affordable clothing options for everyone.
      </MissionStatement>
      <Vision>
        Our vision is to become a leading global fashion retailer known for our commitment to quality, style, and customer satisfaction.
      </Vision>
      <Values>
        <ValueItem><strong>Quality:</strong> We prioritize quality in every product we offer.</ValueItem>
        <ValueItem><strong>Style:</strong> We stay ahead of fashion trends to bring you the latest styles.</ValueItem>
        <ValueItem><strong>Affordability:</strong> Providing fashion at affordable prices for all.</ValueItem>
      </Values>
      <p>
        Trendware is dedicated to providing exceptional customer service and a seamless shopping experience. We are committed to sustainability through our eco-friendly practices and initiatives.
      </p>
      <p>
        For more information or inquiries, feel free to <a href="/contact">contact us</a>.
      </p>
    </AboutContainer>
  );
};

export default About;
