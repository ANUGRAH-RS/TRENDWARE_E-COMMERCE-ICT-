import React from 'react';
import styled from 'styled-components';
import About from './About';
import footer_logo from '../Assets/logo_big.png';
import instagram_icon from '../Assets/instagram_icon.png';
import pintrest_icon from '../Assets/pintester_icon.png';
import whatsapp_icon from '../Assets/whatsapp_icon.png';
import { Link } from 'react-router-dom';

const FooterContainer = styled.div`
  background-color: #232f3e;
  color: #fff;
  padding: 40px 20px;
  text-align: center;
`;

const FooterLogo = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 20px;

  img {
    width: 100px;
    height: auto;
  }

  p {
    font-size: 1.2rem;
    margin-top: 10px;
    font-weight: bold;
  }
`;

const FooterLinks = styled.ul`
  list-style: none;
  padding: 0;
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;

  li {
    font-size: 0.9rem;
    color: #ccc;
    cursor: pointer;
    transition: color 0.3s;

    &:hover {
      color: #fff;
    }
  }
`;

const FooterSocialIcons = styled.div`
  display: flex;
  justify-content: center;
  gap: 20px;
  margin-bottom: 20px;
`;

const FooterIconContainer = styled.div`
  width: 40px;
  height: 40px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 50%;
  background-color: #3b5998; /* Facebook blue */
  transition: background-color 0.3s;

  &:hover {
    background-color: #385898;
  }

  img {
    width: 20px;
    height: 20px;
  }
`;

const FooterCopyright = styled.div`
  border-top: 1px solid #444;
  padding-top: 20px;

  p {
    font-size: 0.8rem;
    color: #999;
  }
`;

const Footer = () => {
  return (
    <FooterContainer>
      <FooterLogo>
        <img src={footer_logo} alt="Shopper logo" />
        <p>TRENDWARE</p>
      </FooterLogo>
      <FooterLinks>
        
        <li><Link to="/products">Products</Link></li>
        
        <li><Link to="/about">About</Link></li>       
        <li><Link to="/co">Contact</Link></li>
      </FooterLinks>

      <FooterSocialIcons>
        <FooterIconContainer>
          <img src={instagram_icon} alt="Instagram" />
        </FooterIconContainer>
        <FooterIconContainer>
          <img src={pintrest_icon} alt="Pinterest" />
        </FooterIconContainer>
        <FooterIconContainer>
          <img src={whatsapp_icon} alt="WhatsApp" />
        </FooterIconContainer>
      </FooterSocialIcons>
      <FooterCopyright>
        <p>© 2024 TRENDWARE. All Rights Reserved.</p>
      </FooterCopyright>
    </FooterContainer>
  );
};

export default Footer;
