import React from 'react';
import './Popular.css';
import Item from '../Item/Item';

const Popular = (props) => {
  return (
    <div className='popular'>
      <h1>POPULAR IN WOMEN</h1>
      <hr />
      <div className="popular-item">
        {props.data.map((item, index) => (
          <div className="item" key={index}>
            <img src={item.image} alt={item.name} />
            <div className="item-details">
              <p className="item-name">{item.name}</p>
              <div className="item-price">
                <span className="new-price">${item.new_price}</span>
                {item.old_price && <span className="old-price">${item.old_price}</span>}
              </div>
              <div className="item-actions">
                <button>Add to Cart</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Popular;
